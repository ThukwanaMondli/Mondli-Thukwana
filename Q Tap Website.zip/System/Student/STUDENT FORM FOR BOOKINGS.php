<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>One-on-One Session Booking</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f4f4f4;
        }

        .container {
            text-align: center;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 10px;
            background-color: white;
        }
        .cont {
            text-align: center;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 10px;
            background-color: white;
            display: flex; /* Add display:flex to make the children elements align in a row */
            align-items: center; /* Align items vertically in the center */
        }

        form {
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            margin-bottom: 10px;
            display: block;
        }

        input {
            width: calc(100% - 20px);
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            background-color: #4caf50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        #confirmation {
            font-weight: bold;
            color: #4caf50;
            margin-top: 20px;
        }
        svg {
            width: 24px;
            height: 24px;
            cursor: pointer;
            margin-right: 10px;
            fill: #000;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="cont">
            <a href="#" onclick="goBack()">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18 12L6 12M6 12L11 17M6 12L11 7" stroke="#000000" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </a>
            <h1>One-on-One Session Booking</h1>
        </div>
        
        <form id="bookingForm" onsubmit="submitForm(event)">
            <label for="studentNumber">Student Number:</label>
            <input type="text" id="studentNumber" required><br>

            <label for="module">Module Name:</label>
            <input type="text" id="module" required><br>

            <label for="topic">Topic:</label>
            <input type="text" id="topic" required><br>

            <label for="lecture_Email">Lecture's Email:</label>
            <input type="email" id="lecture_Email" required><br>

            <label for="date">Date:</label>
            <input type="date" id="date" required><br>

            <label for="Session_Preferred">Session Preferred:</label>
            <input type="text" id="Session_Preferred" required><br>

            <button type="submit">Book Session</button>
        </form>
        
        <button id="StatusButton" class="status-button" onclick="status()">STATUS</button>
        <div id="confirmation"></div>
    </div>

    <script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-auth.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-firestore.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-database.js"></script>
<script src="https://smtpjs.com/v3/smtp.js"></script>

    <script> 
	// Initialize Firebase with your project's config
  var firebaseConfig = {
  apiKey: "AIzaSyAoq1oa-NBqQieyFUSM0x_1oALtUR5oYyY",
  authDomain: "test-abe72.firebaseapp.com",
  databaseURL: "https://test-abe72-default-rtdb.firebaseio.com",
  projectId: "test-abe72",
  storageBucket: "test-abe72.appspot.com",
  messagingSenderId: "684875273850",
  appId: "1:684875273850:web:62b53302ee9db7dc930dc3",
  measurementId: "G-X42D961KTD"
  };
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  // Initialize Firebase
firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const database = firebase.database();
const firestore = firebase.firestore();
        function status(){
            window.location.href = "Booking_Status.php";
        }

        function goBack() {
            window.history.back();
        }

        function submitForm(event) {
            event.preventDefault(); // Prevent default form submission
            var form = document.getElementById("bookingForm");
            var formData = new FormData(form);
            // Here you would send formData to your backend for processing
            // For demonstration, let's just show a confirmation message:
            var confirmationDiv = document.getElementById("confirmation");
            confirmationDiv.innerText = "Booking confirmed!";

            // Clear the form after submission
            form.reset();
        }
		


        function submitForm(event) {
            event.preventDefault(); // Prevent default form submission

            // Retrieve form data
            var studentNumber = document.getElementById("studentNumber").value;
            var module = document.getElementById("module").value;
            var topic = document.getElementById("topic").value;
            var lectureEmail = document.getElementById("lecture_Email").value;
            var date = document.getElementById("date").value;
            var sessionPreferred = document.getElementById("Session_Preferred").value;

            // Check if any field is missing
            if (!studentNumber || !module || !topic || !lectureEmail || !date || !sessionPreferred) {
                alert("Please fill in all fields.");
                return;
            }

            // Check if the selected date is not a previous date
            var today = new Date().toISOString().split('T')[0];
            if (date < today) {
                alert("Please select a future date.");
                return;
            }
			var userSession = localStorage.getItem('userSession');
            // Add data to Firestore
            firestore.collection("bookings").add({
                studentNumber: studentNumber,
                module: module,
                Email: userSession,
                chapterName: topic,
                lectureEmail: lectureEmail,
                date: date,
                sessionPreferred: sessionPreferred,
                accept: "Pending", // Assuming this is the initial status
                venue: "Wait", // Assuming this is the initial status
                resolved: false, // Assuming this is the initial status
                statusClass: false // Assuming this is the initial status
            })
                .then(function (docRef) {
                    // Clear the form after successful submission
                    document.getElementById("bookingForm").reset();
                    // Show confirmation message
                    document.getElementById("confirmation").innerText = "Booking confirmed!";
                    // Send email to lecturer
                      sendEmailToLecturer(userSession, lectureEmail, studentNumber, module, date, sessionPreferred);
        
                })
                .catch(function (error) {
                    // Handle errors
                    console.error("Error adding document: ", error);
                    document.getElementById("confirmation").innerText = "An error occurred. Please try again.";
                });
        }

        function sendEmailToLecturer(userSession, lectureEmail, studentNumber, module, date, sessionPreferred) {
        Email.send({
            SecureToken: "3538F8D98136B6CE6AD31967785B0729937DC583A43C3179D81CAD7537ECF5CAC09D5078BFC2734AA9862E48E1C32373", // Your SMTPJS secure token
            To: lectureEmail,
            From: userSession, // Use the user's session email as the sender
            Subject: "Booking Confirmation",
            Body: `
                <p>Hello Lecturer,</p>
                <p>A booking has been made by student number ${studentNumber} for module ${module} on ${date} (${sessionPreferred}).</p>
                <p>Thank you.</p>
            `
        }).then(function (message) {
            console.log("Email sent to lecturer:", message);
        }).catch(function (error) {
            console.error("Error sending email:", error);
        });
}

    </script>
</body>

</html>
