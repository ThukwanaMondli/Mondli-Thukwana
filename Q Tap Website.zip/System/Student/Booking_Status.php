<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Your head content here -->
    <style>
body {
            font-family: Arial, sans-serif;
            background: url("css\img.png") no-repeat center center fixed;
            background-size: cover;
			background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }

        .container {
            background: #f0f0f0;
            padding: 40px;
            display: flex;
            flex-direction: column;
            align-items: center;
			margin-top: 100px
        }

        h1 {
            color: #851616;
            text-align: center;
            font-size: 30px;
            font-style: italic;
            font-weight: bold;
            background: #E663E4F4;
            padding: 50px;
            border-radius: 10px;
			margin-top: 40px;
        }

        table a:link {
	color: #666;
	font-weight: bold;
	text-decoration: none;
}

table a:visited {
	color: #999999;
	font-weight: bold;
	text-decoration: none;
}

table a:active,
table a:hover {
	color: #bd5a35;
	text-decoration: underline;
}

table {
	width: 1200px;
	margin:10px auto;
	box-shadow: none;
	border:1px solid #E6E6E6;
	padding:0;
	background-color:#FFFFFF;
	box-sizing: border-box;
	display: table;
}

table th {
	text-align:center;
	background: #34495e;
	color:#FFF;
	text-shadow:0px 01px 0px #000;
	font-size:15px;
	height: 42px;
	border-radius: 0 !important;
	border-left: 1px solid whitesmoke;
	box-sizing:border-box;
}

table th:first-child {
	border-left: 0;
}


table tr {
	text-align: center;
}

table td:first-child {
	box-sizing: border-box;
	border-left: 0;
}

table td {
	padding: 9px;
	border-top: 1px solid #ffffff;
	border-bottom: 1px solid #e0e0e0;
	border-left: 1px solid #e0e0e0;
	background: white;
}

table tr:nth-child(odd) td {
	background: #fcfaf5;
}

table tr:last-child td {
	border-bottom: 0;
}

table tr:hover td {
	background: #fffcf5;
	background: -webkit-gradient(linear, left top, left bottom, from(#f2f2f2), to(#f0f0f0));
	background: -moz-linear-gradient(top, #f2f2f2, #f0f0f0);
}
        .pending {
            color: red;
        }

        .approved {
            color: green;
        }
		.cont {
            text-align: center;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 10px;
            background-color: #f0f0f0;
            display: flex; /* Add display:flex to make the children elements align in a row */
            align-items: center; /* Align items vertically in the center */
        }
svg {
            width: 44px;
            height: 44px;
            cursor: pointer;
            margin-right: 10px;
            fill: #000;
        }
    </style>
</head>

<body>

    <div class="container">
        <caption>Availability Schedule</caption>
        
		<div class="cont">
	<a href="#" onclick="goBack()">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 12L6 12M6 12L11 17M6 12L11 7" stroke="#000000" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </a><h2>Bookings</h2>
	</div>
        <table>
            <thead>
                <tr>
                    <th>Student Number</th>
                    <th>Date</th>
                    <th>Module</th>
                    <th>chapterName</th>
                    <th>Time</th>
                    <th>venue</th>
                    <th>accept</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody id="bookingsTableBody">
                <!-- Booking details will be added here -->
            </tbody>
        </table>
    </div>
	<script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-firestore.js"></script>
    <script>
        // Initialize Firebase with your project's config
		  var firebaseConfig = {
			  apiKey: "AIzaSyAoq1oa-NBqQieyFUSM0x_1oALtUR5oYyY",
			  authDomain: "test-abe72.firebaseapp.com",
			  databaseURL: "https://test-abe72-default-rtdb.firebaseio.com",
			  projectId: "test-abe72",
			  storageBucket: "test-abe72.appspot.com",
			  messagingSenderId: "684875273850",
			  appId: "1:684875273850:web:62b53302ee9db7dc930dc3",
			  measurementId: "G-X42D961KTD"};
			   // Initialize Firebase with your project's config
    

    // Initialize Firebase only once
    if (!firebase.apps.length) {
        firebase.initializeApp(firebaseConfig);
    }
    var userSession = localStorage.getItem('userSession');

    const firestore = firebase.firestore();
    // Listen for changes in the "bookings" collection and update the table
    const bookingsTableBody = document.getElementById("bookingsTableBody");

    firestore.collection("bookings").where("Email", "==", userSession).onSnapshot((querySnapshot) => {
        bookingsTableBody.innerHTML = ""; // Clear the table

        querySnapshot.forEach((doc) => {
            const booking = doc.data();
            const row = document.createElement("tr");
            // Check the statusClass and apply appropriate class for styling
            const resolved = booking.resolved === true ? "approved" : "pending";
            row.innerHTML = `
                <td>${booking.studentNumber}</td>
                <td>${booking.date}</td>
               
                <td>${booking.module}</td>
                <td>${booking.chapterName}</td>
				 <td>${booking.time !== undefined ? booking.time : 'Wait'}</td>
                <td>${booking.venue !== undefined ? booking.venue : 'No venue assigned'}</td>
                <td>${booking.accept}</td>
                <td class="${resolved}">${booking.resolved === true ? 'approved' : 'pending'}</td>
            `;
            bookingsTableBody.appendChild(row);
        });
    });

    function goBack() {
        window.history.back();
    }
	</script>
</body>

</html>
