<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" href="css\style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        h2 {
            color: black;
            text-align: center;
            font-size: 30px;
            font-style: italic;
            font-weight: bold;
            padding: 50px;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <h2>MANAGERS</h2>
    <table>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>POSITION</th>
        </tr>
        <tr>
            <td>MR KWALE</td>
            <td><a href="mailto:kwale@iie.edu.za">kwale@iie.edu.za</a></td>
            <td>PRINCIPAL</td>
        </tr>
        <tr>
            <td>MRS JAY</td>
            <td><a href="mailto:jay@iie.edu.za">jay@iie.edu.za</a></td>
            <td>VICE PRINCIPAL</td>
        </tr>
        <tr>
            <td>MR PETRO</td>
            <td><a href="mailto:petro2@iie.edu.za">petro2@iie.edu.za</a></td>
            <td>CEO</td>
        </tr>
    </table>
	
</body>
</html>
