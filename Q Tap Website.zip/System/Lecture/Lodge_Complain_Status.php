<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        .booking {
            background-color: #fff;
            border: 1px solid #ccc;
            margin-bottom: 20px;
            padding: 20px;
            border-radius: 20px; /* Rounded corners */
        }

        .booking p {
            margin: 10px 0; /* Add some gap between each paragraph */
        }

        .booking-info {
            border-top: 1px solid #ccc;
            padding-top: 10px;
            margin-top: 10px;
        }

        .admin-response {
            margin-top: 20px;
        }

        .admin-response textarea {
            width: 100%;
            resize: vertical; /* Allow vertical resizing */
        }
		.accept-button, .decline-button {
            width: 150px; /* Adjust button width */
            padding: 10px; /* Add padding */
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            margin-right: 10px;
            text-align: center;
        }

        .accept-button {
            background-color: green;
            color: white;
        }

        .decline-button {
            background-color: red;
            color: white;
        }
		.cont {
            text-align: center;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 10px;
            background-color: white;
            display: flex; /* Add display:flex to make the children elements align in a row */
            align-items: center; /* Align items vertically in the center */
        }
		svg {
            width: 24px;
            height: 24px;
            cursor: pointer;
            margin-right: 10px;
            fill: #000;
        }
    </style>
</head>
<body>
    <div class="container">
	<div class="cont">
            <a href="#" onclick="goBack()">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18 12L6 12M6 12L11 17M6 12L11 7" stroke="#000000" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </a>
           <h1>Student Booking Details</h1>
        </div>
        
        <div class="sort-controls">
            <label>Sort By:</label>
            <select id="sortField">
                <option value="studentNumber">Student Number</option>
                <option value="date">Date</option>
                <option value="time">Time</option>
                <option value="accept">Accepted</option>
            </select>
            <label>Order:</label>
            <select id="sortOrder">
                <option value="asc">Ascending</option>
                <option value="desc">Descending</option>
            </select>
            <button onclick="sortBookings()">Sort</button>
        </div>
        <div id="bookingList"></div>
    </div>
	
    <script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-firestore.js"></script>
    <script>
        // Initialize Firebase with your project's config
        var firebaseConfig = {
            apiKey: "AIzaSyAoq1oa-NBqQieyFUSM0x_1oALtUR5oYyY",
            authDomain: "test-abe72.firebaseapp.com",
            databaseURL: "https://test-abe72-default-rtdb.firebaseio.com",
            projectId: "test-abe72",
            storageBucket: "test-abe72.appspot.com",
            messagingSenderId: "684875273850",
            appId: "1:684875273850:web:62b53302ee9db7dc930dc3",
            measurementId: "G-X42D961KTD"
        };

        // Initialize Firebase only once
        if (!firebase.apps.length) {
            firebase.initializeApp(firebaseConfig);
        }

        const firestore = firebase.firestore();
        const bookingList = document.getElementById('bookingList');
		function goBack() {
            window.history.back();
        }
        function checkUserSignIn() {
            var userSession = localStorage.getItem('userSession');
            if (userSession != null) {
                // User is signed in
                // Retrieve the logged-in user's email
                var userEmail = localStorage.getItem('userSession');

                firestore.collection("bookings").where("lectureEmail", "==", userEmail)
                    .onSnapshot((querySnapshot) => {
                        const bookings = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                        displayBookings(bookings);
                    });
            } else {
                // User session is null, redirect to login page
                window.location.href = "Login.php";
            }
        }
        
        function sortBookings() {
            const sortField = document.getElementById('sortField').value;
            const sortOrder = document.getElementById('sortOrder').value;  
			var userEmail = localStorage.getItem('userSession');
            firestore.collection("bookings").where("lectureEmail", "==", userEmail).orderBy(sortField, sortOrder)
                .onSnapshot((querySnapshot) => {
					const bookings = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
//const bookings = querySnapshot.docs.map(doc => doc.data());
                    displayBookings(bookings);
                });
        }

        // Call the checkUserSignIn function to check the user's sign-in status
        checkUserSignIn();

       function displayBookings(bookings) {
    bookingList.innerHTML = '';
    bookings.forEach(doc => { // Change 'booking' to 'doc' here
        const bookingItem = document.createElement('div');
        bookingItem.className = 'booking';
        //const booking = doc.data(); // Retrieve booking data from the document snapshot
       // bookingItem.id = doc.id; // Set the ID of the bookingItem to the document ID
	   //console.log(doc.id);
	   // Set background color based on conditions
        let backgroundColor = '';
        if (doc.statusClass && doc.venue !== null) {
            backgroundColor = 'green'; // If statusClass is true and venue is Unsuccessful
        } else if (!doc.statusClass && doc.venue === 'Unsuccessful') {
            backgroundColor = 'red'; // If statusClass is false and venue is Unsuccessful
        } else if (doc.statusClass === undefined || doc.statusClass === null) {
            backgroundColor = 'orange'; // If statusClass is undefined or null
        } else {
            backgroundColor = 'yellow'; // Default background color
        }
        
        // Set the background color style
        bookingItem.style.backgroundColor = backgroundColor;

        bookingItem.innerHTML = `
            <p><strong>Student Number:</strong> ${doc.studentNumber}</p>
            <p><strong>Email:</strong> ${doc.Email}</p>
            <p><strong>Chapter Name:</strong> ${doc.chapterName}</p>
            <p><strong>Module:</strong> ${doc.module}</p>
            <p><strong>Lecture Email:</strong> ${doc.lectureEmail}</p>
            <p><strong>Date:</strong> ${doc.date}</p>
            <p><strong>Time:</strong> ${doc.time}</p>
            <p><strong>Venue:</strong> ${doc.venue}</p>
            <p><strong>Session Preferred:</strong> ${doc.sessionPreferred}</p>
            <p><strong>Accept:</strong> ${doc.accept}</p>
            <p><strong>Status:</strong> ${doc.statusClass ? 'Booked' : 'Not Booked'}</p>
           
            <div class="admin-actions">
                <button class="accept-button" onclick="acceptBooking('${doc.id}')">Accept</button>
                <button class="decline-button" onclick="declineBooking('${doc.id}')">Decline</button>
            </div>
        `;
        bookingList.appendChild(bookingItem);
    });
}



function acceptBooking(bookingId) {
	
	alert("Booking accepted and updated successfully." + bookingId);
    const time = prompt("Enter Time:");
    const venue = prompt("Enter Venue:");
    const date = prompt("Enter Date (YYYY-MM-DD):");

    if (time && venue && date) {
        const accept = confirm(`Are you sure you want to accept this booking for ${date}, ${time}, at ${venue}?`);
        if (accept) {
            // Update booking details in Firestore
            firestore.collection("bookings").doc(bookingId).update({
                time: time,
                venue: venue,
                date: date,
                accept: 'accepted',
                statusClass: true,
                resolved: true
            }).then(() => {
                alert("Booking accepted and updated successfully.");
            }).catch((error) => {
                console.error("Error updating document: ", error);
            });
        }
    }
}

function declineBooking(bookingId) {
    const confirmDecline = confirm("Are you sure you want to decline this booking?");
    if (confirmDecline) {
        // Update booking details in Firestore
        firestore.collection("bookings").doc(bookingId).update({
            time: '',
            venue: 'Unsuccessful',
            date: '',
            accept: 'not accepted',
            statusClass: false,
            resolved: false
        }).then(() => {
            alert("Booking declined and updated successfully.");
        }).catch((error) => {
            console.error("Error updating document: ", error);
        });
    }
}



/*        function submitAdminResponse(key) {
            const adminResponse = document.getElementById(`adminResponse${key}`).value;
            if (adminResponse.trim() !== '') {
                firestore.collection("bookings").doc(key).update({ adminResponse: adminResponse })
                    .then(() => {
                        alert(`Admin response submitted for Booking ID ${key}.`);
                    })
                    .catch(error => {
                        console.error("Error updating document: ", error);
                    });
            } else {
                alert("Please enter a valid admin response.");
            }
        }*/
    </script>
</body>
</html>
