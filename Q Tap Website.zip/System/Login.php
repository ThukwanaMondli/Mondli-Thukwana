<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/style.css">
    <title>Q-Tap</title>
    <style>
	.modal{
    position: absolute;
    left: 4px;
    width: 500px;
    display: flex;
    flex-direction: column;
    transition: .5s ease-in-out;
}
        .ring {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 150px;
            height: 150px;
            background: transparent;
            border: 3px solid #3c3c3c;
            border-radius: 50%;
            text-align: center;
            line-height: 150px;
            font-family: sans-serif;
            font-size: 20px;
            color: #fff000;
            letter-spacing: 4px;
            text-transform: uppercase;
            text-shadow: 0 0 10px #fff000;
            box-shadow: 0 0 20px rgba(0, 0, 0, .5);
        }

        .ring:before {
            content: '';
            position: absolute;
            top: -3px;
            left: -3px;
            width: 100%;
            height: 100%;
            border: 3px solid transparent;
            border-top: 3px solid #fff000;
            border-right: 3px solid #fff000;
            border-radius: 50%;
            animation: animateC 2s linear infinite;
        }

        .loading-text {
            animation: spinText 2s linear infinite;
        }

        @keyframes spinText {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
        }

        @keyframes animateC {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
        }
    </style>
</head>
<body>

<div class="wrapper">
    <nav class="nav">
        <div class="nav-logo">
            <img src="Student/css/pic__2_-removebg-preview.png" alt="Logo" width="100" height="100">
        </div>
        <div class="nav-menu" id="navMenu">
           <ul>
                <li><a href="https://www.rosebankcollege.co.za/" class="link active">Home</a></li>
                <li><a href="Services.html" class="link">Services</a></li>
                
            </ul>
        </div>
    </nav>

    <!-- Form box -->
    <div class="form-box">
        <!-- Login form -->
        <div class="ring" id="loadingRing">
            <span class="loading-text">Loading</span>
            <span></span>
        </div>
<!-- Forgot password modal -->
        <div id="forgotPasswordModal" class="modal" style="display: none;">
            <div class="modal-content">
                <div class="top">
                    <span><a href="#" onclick="signIn()">Sign in</a></span>
                    <header>Reset Password</header>
                </div>
                <div class="input-box">
                    <input type="text" class="input-field" id="forgotPasswordEmail" placeholder="Enter Email"> 
                    <i class="bx bx-user"></i>
                </div>
                <button class="submit" onclick="sendResetPasswordEmail()">Reset Link</button>
                <div class="input-box">
                    <button class="submit" id="btnCancel" onclick="closeModal()">Cancel</button>
                </div>
            </div>
        </div>

        <div class="login-container" id="login">
            <div class="top">
                <span>Don't have an account? <a href="Register.php" onclick="register()">Sign Up</a></span>
                <header>Login</header>
            </div>
            <div class="input-box">
                <input type="text" class="input-field" id="loginEmail" placeholder="Email">
                <i class="bx bx-user"></i>
            </div>
            <div class="input-box">
                <input type="password" class="input-field" id="loginPassword" placeholder="Password">
                <i class="bx bx-lock-alt"></i>
            </div>
            <div class="input-box">
                <input type="submit" class="submit" id="submit" onclick="loginUser()" value="Sign In">
            </div>
            <div class="two-col">
                <div class="one">
                    <input type="checkbox" id="login-check">
                    <label for="login-check"> Remember Me</label>
                </div>
                <div class="two">
                    <label><a  onclick="ForgotPassword()" >Forgot password?</a></label>
                </div>
            </div>
            <div id="loadingContainer" style="display: none;">
                <div class="loading-spinner"></div>
            </div>
        </div>
    </div>
</div>

<script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-firestore.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.10.1/firebase-database.js"></script>
<script> 
    function showLoadingRing() {
        const loadingRing = document.getElementById("loadingRing");
        loadingRing.style.display = "block";
    }

    function hideLoadingRing() {
        const loadingRing = document.getElementById("loadingRing");
        loadingRing.style.display = "none";
    }

    hideLoadingRing();

     document.addEventListener("DOMContentLoaded", function() {
        // Find the submit button and add an event listener to it
        document.getElementById("submit").addEventListener("click", function() {
            // Call showLoadingRing() when the submit button is clicked
            showLoadingRing();
            // Perform your login logic here
        });
    });
	document.addEventListener("DOMContentLoaded", function() {
        // Find elements
        var forgotPassword = document.getElementById("forgotTittle");
        var editBox = document.getElementById("editBox");
        var btnCancel = document.getElementById("btnCancel");
        var btnReset = document.getElementById("btnReset");
        
		btnCancel.addEventListener("click", function() {
            Sign_In();
        });

        
    });
function ForgotPassword() {
  document.getElementById("forgotPasswordModal").style.display = "block";
  document.getElementById("login").style.display = "block";
document.getElementById("login").style.display = "none";
}
// Function to display the modal
function openModal() {
  document.getElementById("forgotPasswordModal").style.display = "block";
}
document.querySelector('a[href="#"]').addEventListener("click", function(event) {
  event.preventDefault(); // Prevent the default action of the anchor link
  openModal(); // Display the forgot password modal
});
function Sign_In() {
  document.getElementById("login").style.display = "block";
  document.getElementById("forgotPasswordModal").style.display = "block";
document.getElementById("forgotPasswordModal").style.display = "none";
}
function sendResetPasswordEmail() {
    // Get the user's email from the input field
    const email = document.getElementById("forgotPasswordEmail").value;
    if (email != null) {
        // Send the reset password email
        auth.sendPasswordResetEmail(email)
            .then(() => {
                // Reset password email sent successfully
                alert("Reset password email sent successfully. Please check your email inbox.");
                // Close the modal after sending the email
                closeModal();
                hideLoadingRing();
            })
            .catch((error) => {
                // Handle any errors that occur during the process
                
                alert("An error occurred while sending the reset password email. Please try again later.");
            });
    } else {
        // Display an error message if the email is empty
        alert("Please enter your email address.");
    }
}

</script>
<script src="index.js"></script>

</body>
</html>
